<?php
include 'config.php';
if(!isset($_SESSION['user'])) header("Location: login.php");

// Ambil data user
$user_id = $_SESSION['user'];

// Ambil semua task user
$tasks = mysqli_query($conn,"SELECT * FROM tasks WHERE user_id='$user_id' ORDER BY due_date ASC");

// Statistik
$total   = mysqli_num_rows(mysqli_query($conn,"SELECT * FROM tasks WHERE user_id='$user_id'"));
$done    = mysqli_num_rows(mysqli_query($conn,"SELECT * FROM tasks WHERE user_id='$user_id' AND status='Done'"));
$pending = mysqli_num_rows(mysqli_query($conn,"SELECT * FROM tasks WHERE user_id='$user_id' AND status='Pending'"));
?>

<!DOCTYPE html>
<html>
<head>
  <title>Pinky Dashboard</title>
  <link rel="stylesheet" href="style.css">
  <script src="script.js"></script>
</head>
<body class="<?= $_SESSION['theme'] ?>">

<div class="theme-toggle">
  <a href="theme.php" class="btn-sm">🌙 / ☀️</a>
</div>

<div class="dashboard-container">

  <!-- Sidebar -->
<div class="sidebar">
  <h2>🐷 Pinky</h2>
  <a href="dashboard.php">🏠 Dashboard</a>
  <a href="pomodoro.php">🍅 Pomodoro</a>
  <a href="reminder.php">⏰ Pengingat</a>
  <a href="logout.php">🚪 Logout</a>
</div>

  <!-- Main -->
  <div class="main">

    <!-- Header -->
    <div class="header">
      <h1>Welcome to Pinky To-Do</h1>
      <p>Make your day more productive</p>
    </div>

    <!-- Statistik -->
    <div class="stats">
      <div class="stat-card">
        <h3>Total Task</h3>
        <p><?= $total ?></p>
      </div>
      <div class="stat-card">
        <h3>Completed</h3>
        <p><?= $done ?></p>
      </div>
      <div class="stat-card">
        <h3>Pending</h3>
        <p><?= $pending ?></p>
      </div>
    </div>

    <!-- Task List -->
    <div class="task-section">
      <div class="task-header">
        <h2>Your Tasks</h2>
        <a href="task_add.php" class="btn">+ Add Task</a>
      </div>

      <div class="task-list">
        <?php while($t = mysqli_fetch_assoc($tasks)) { ?>
          <div class="task-card <?= $t['status']=='Done'?'done':'' ?>" style="border-left:6px solid <?= $t['label_color'] ?>">

            <div class="task-info">
              <h3><?= $t['title'] ?></h3>
              <p><?= $t['description'] ?></p>
              <small>Due: <?= $t['due_date'] ?> | Priority: <?= $t['priority'] ?></small>
            </div>

            <div class="task-action">
              <?php if($t['status']=='Pending'){ ?>
                <a href="task_done.php?id=<?= $t['id'] ?>" class="btn-sm done">✓</a>
              <?php } ?>
              <a href="task_edit.php?id=<?= $t['id'] ?>" class="btn-sm edit">✏</a>
              <a href="task_delete.php?id=<?= $t['id'] ?>" class="btn-sm delete" onclick="return confirm('Delete task?')">🗑</a>
            </div>

          </div>
        <?php } ?>
      </div>
    </div>

  </div>

</div>

</body>
</html>
