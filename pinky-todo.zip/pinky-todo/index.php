<?php session_start(); ?>
<!DOCTYPE html>
<html>
<head>
  <title>Pinky To-Do List</title>
  <link rel="stylesheet" href="style.css">
  <script src="theme.js"></script>
</head>
<body class="light">

<div class="theme-toggle">
  <button onclick="toggleTheme()">🌙 / ☀️</button>
</div>

<div class="hero">
  <div class="hero-card">
    <h1>🐷 Pinky To-Do List</h1>
    <p>Organize your life beautifully</p>
    <p>
    <div class="hero-btn">
      <a href="login.php" class="btn">Login</a>
      <a href="register.php" class="btn btn-outline">Register</a>
    </div>
  </div>
</div>

</body>
</html>
