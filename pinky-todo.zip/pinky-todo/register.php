<?php
include 'config.php';

if(isset($_POST['register'])){
  $name  = $_POST['name'];
  $email = $_POST['email'];
  $pass  = md5($_POST['password']);

  mysqli_query($conn,"INSERT INTO users(name,email,password) VALUES('$name','$email','$pass')");
  header("Location: login.php");
}
?>
<!DOCTYPE html>
<html>
<head>
  <title>Register - Pinky</title>
  <link rel="stylesheet" href="style.css">
  <script src="theme.js"></script>
</head>
<body class="<?= isset($_SESSION['theme']) ? $_SESSION['theme'] : 'light' ?>">


<div class="theme-toggle">
  <button onclick="toggleTheme()">🌙 / ☀️</button>
</div>

<div class="auth-container">
  <div class="auth-card">
    <h2>Register</h2>
    <form method="post">
      <input type="text" name="name" placeholder="Full Name" required>
      <input type="email" name="email" placeholder="Email" required>
      <input type="password" name="password" placeholder="Password" required>
      <button name="register" class="btn">Register</button>
    </form>
  </div>
</div>

</body>
</html>
