<?php
include 'config.php';
$id = $_GET['id'];
mysqli_query($conn,"DELETE FROM reminders WHERE id='$id'");
header("Location: reminder.php");
?>
