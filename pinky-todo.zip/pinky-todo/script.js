function toggleTheme(){
  document.body.classList.toggle("dark");
  document.body.classList.toggle("light");
}

document.addEventListener("DOMContentLoaded", function(){

  let time = 1500;
  let timer = null;
  let running = false;

  const timeDisplay = document.getElementById("time");
  const statusText  = document.getElementById("status");
  const startBtn    = document.getElementById("startBtn");
  const resetBtn    = document.getElementById("resetBtn");

  if(!startBtn){
    console.log("Tombol start tidak ditemukan!");
    return;
  }

  startBtn.onclick = function(){
    if(running) return;
    running = true;
    statusText.innerText = "Focus time! 🔥";

    timer = setInterval(function(){
      let minutes = Math.floor(time / 60);
      let seconds = time % 60;

      timeDisplay.innerText =
        String(minutes).padStart(2,'0') + ":" +
        String(seconds).padStart(2,'0');

      if(time <= 0){
        clearInterval(timer);
        running = false;
        statusText.innerText = "Time's up! Take a break ☕";
        alert("Pomodoro selesai! Istirahat dulu ya 💖");
        return;
      }

      time--;
    },1000);
  };

  resetBtn.onclick = function(){
    clearInterval(timer);
    running = false;
    time = 1500;
    timeDisplay.innerText = "25:00";
    statusText.innerText = "Ready to focus";
  };

});
