<?php
include 'config.php';
$id = $_GET['id'];
mysqli_query($conn,"UPDATE reminders SET status='Done' WHERE id='$id'");
?>
