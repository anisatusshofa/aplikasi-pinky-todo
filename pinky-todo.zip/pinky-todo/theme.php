<?php
include 'config.php';

$uid = $_SESSION['user'];
$new = ($_SESSION['theme']=='light') ? 'dark' : 'light';

mysqli_query($conn,"UPDATE users SET theme='$new' WHERE id='$uid'");
$_SESSION['theme'] = $new;

header("Location: ".$_SERVER['HTTP_REFERER']);
?>
