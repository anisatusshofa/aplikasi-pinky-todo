<?php
include 'config.php';
if(!isset($_SESSION['user'])) header("Location: login.php");
?>

<!DOCTYPE html>
<html>
<head>
  <title>Pomodoro - Pinky</title>
  <link rel="stylesheet" href="style.css">
</head>

<body class="<?= $_SESSION['theme'] ?>">

<div class="theme-toggle">
  <a href="theme.php" class="btn-sm">🌙 / ☀️</a>
</div>

<div class="dashboard-container">

<div class="sidebar">
  <h2>🐷 Pinky</h2>
  <a href="dashboard.php">🏠 Dashboard</a>
  <a href="pomodoro.php">🍅 Pomodoro</a>
  <a href="reminder.php">⏰ Pengingat</a>
  <a href="logout.php">🚪 Logout</a>
</div>

  <div class="main">

    <div class="task-section pomodoro-card">

      <h2>🍅 Pomodoro Focus</h2>
      <p>Stay focused and be productive</p>

      <div class="pomodoro-timer">
        <h1 id="time">25:00</h1>
      </div>

      <div class="pomodoro-btn">
        <button class="btn" id="startBtn">Start</button>
        <button class="btn-outline" id="resetBtn">Reset</button>
      </div>

      <p id="status">Ready to focus</p>

    </div>

  </div>

</div>

<script src="script.js"></script>
</body>
</html>
