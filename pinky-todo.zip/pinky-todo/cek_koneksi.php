<?php
$conn = mysqli_connect("127.0.0.1","root","","pinky_todo");

if($conn){
    echo "Koneksi database berhasil!";
}else{
    echo "Koneksi gagal!";
}
?>
