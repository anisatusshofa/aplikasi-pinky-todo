<?php
include 'config.php';
mysqli_query($conn,"UPDATE tasks SET status='Done' WHERE id='$_GET[id]'");
header("Location: dashboard.php");
?>
