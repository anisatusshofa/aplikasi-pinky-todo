<?php
include 'config.php';

if(!isset($_SESSION['user'])){
  header("Location: login.php");
  exit;
}

$id = $_GET['id'];

/* Update reminder */
if(isset($_POST['update'])){
  $title = $_POST['title'];
  $time  = $_POST['time'];

  mysqli_query($conn,"UPDATE reminders 
    SET title='$title', remind_time='$time' 
    WHERE id='$id'");

  header("Location: reminder.php");
  exit;
}

/* Ambil data lama */
$r = mysqli_fetch_assoc(mysqli_query($conn,"SELECT * FROM reminders WHERE id='$id'"));
?>

<!DOCTYPE html>
<html>
<head>
  <title>Edit Pengingat - Pinky Pro</title>
  <link rel="stylesheet" href="style.css">
</head>

<body>

<!-- THEME TOGGLE -->
<div class="theme-toggle">
  <button onclick="toggleTheme()">🌙 / ☀️</button>
</div>

<div class="dashboard-container">

  <!-- SIDEBAR -->
<div class="sidebar">
  <h2>🐷 Pinky</h2>
  <a href="dashboard.php">🏠 Dashboard</a>
  <a href="pomodoro.php">🍅 Pomodoro</a>
  <a href="reminder.php">⏰ Pengingat</a>
  <a href="logout.php">🚪 Logout</a>
</div>

  <!-- MAIN -->
  <div class="main">
    <div class="header">
      <h1>Edit Pengingat</h1>
      <p>Perbarui jadwal pengingat kamu</p>
    </div>

    <div class="task-section">
      <form method="post" class="task-form">
        <input type="text" name="title" value="<?= $r['title'] ?>" required>
        <input type="datetime-local" name="time" 
          value="<?= date('Y-m-d\TH:i', strtotime($r['remind_time'])) ?>" required>
        <button name="update" class="btn">Update Pengingat</button>
        <a href="reminder.php" class="btn btn-outline">Batal</a>
      </form>
    </div>
  </div>

</div>

<script src="theme.js"></script>
</body>
</html>
