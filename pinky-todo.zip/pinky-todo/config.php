<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

$host = "localhost";   // pakai localhost dulu
$user = "root";
$pass = "";
$db   = "pinky_todo";

$conn = mysqli_connect($host, $user, $pass, $db);

if (!$conn) {
    die("Koneksi database gagal: " . mysqli_connect_error());
}
?>
