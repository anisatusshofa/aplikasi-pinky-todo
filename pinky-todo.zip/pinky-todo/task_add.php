<?php
include 'config.php';
if(!isset($_SESSION['user'])) header("Location: login.php");

if(isset($_POST['save'])){
  $title    = $_POST['title'];
  $desc     = $_POST['desc'];
  $priority = $_POST['priority'];
  $color    = $_POST['color'];
  $due      = $_POST['due'];
  $user_id  = $_SESSION['user'];

  mysqli_query($conn,"INSERT INTO tasks 
    (user_id,title,description,priority,label_color,due_date)
    VALUES('$user_id','$title','$desc','$priority','$color','$due')");

  header("Location: dashboard.php");
}
?>

<!DOCTYPE html>
<html>
<head>
  <title>Add Task - Pinky</title>
  <link rel="stylesheet" href="style.css">
  <script src="script.js"></script>
</head>
<body class="<?= $_SESSION['theme'] ?>">

<div class="theme-toggle">
  <a href="theme.php" class="btn-sm">🌙 / ☀️</a>
</div>

<div class="dashboard-container">

<div class="sidebar">
  <h2>🐷 Pinky</h2>
  <a href="dashboard.php">🏠 Dashboard</a>
  <a href="pomodoro.php">🍅 Pomodoro</a>
  <a href="reminder.php">⏰ Pengingat</a>
  <a href="logout.php">🚪 Logout</a>
</div>

  <div class="main">

    <div class="task-section">

      <h2>Add New Task</h2>

      <form method="post" class="task-form">

        <input type="text" name="title" placeholder="Task title" required>

        <textarea name="desc" placeholder="Task description"></textarea>

        <select name="priority">
          <option value="Low">Low Priority</option>
          <option value="Medium">Medium Priority</option>
          <option value="High">High Priority</option>
        </select>

        <label>Label Color</label>
        <input type="color" name="color" value="#ff69b4">

        <label>Due Date</label>
        <input type="datetime-local" name="due" required>

        <button name="save" class="btn">Save Task</button>
        <a href="dashboard.php" class="btn btn-outline">Cancel</a>

      </form>

    </div>

  </div>
</div>

</body>
</html>
