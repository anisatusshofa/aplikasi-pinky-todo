<?php
include 'config.php';

if(!isset($_SESSION['user'])){
  header("Location: login.php");
  exit;
}

$user_id = $_SESSION['user'];

/* Simpan reminder */
if(isset($_POST['save'])){
  $title = $_POST['title'];
  $time  = $_POST['time'];

  mysqli_query($conn,"INSERT INTO reminders(user_id,title,remind_time) 
    VALUES('$user_id','$title','$time')");
}

/* Ambil data reminder */
$data = mysqli_query($conn,"SELECT * FROM reminders 
  WHERE user_id='$user_id' ORDER BY remind_time ASC");
?>


<!DOCTYPE html>
<html>
<head>
  <title>Pengingat - Pinky Pro</title>
  <link rel="stylesheet" href="style.css">
</head>

<body>

<!-- TOGGLE THEME -->
<div class="theme-toggle">
  <button onclick="toggleTheme()">🌙 / ☀️</button>
</div>

<div class="dashboard-container">

  <!-- SIDEBAR -->
<div class="sidebar">
  <h2>🐷 Pinky</h2>
  <a href="dashboard.php">🏠 Dashboard</a>
  <a href="pomodoro.php">🍅 Pomodoro</a>
  <a href="reminder.php">⏰ Pengingat</a>
  <a href="logout.php">🚪 Logout</a>
</div>

  <!-- MAIN -->
  <div class="main">
    <div class="header">
      <h1>⏰ Pengingat & Notifikasi</h1>
      <p>Atur pengingat agar tidak lupa tugas penting</p>
    </div>

    <div class="task-section">

      <!-- FORM -->
      <form method="post" class="task-form">
        <input type="text" name="title" placeholder="Judul pengingat" required>
        <input type="datetime-local" name="time" required>
        <button name="save" class="btn">Set Pengingat</button>
      </form>

      <!-- LIST -->
      <div class="task-list">
<?php while($r = mysqli_fetch_assoc($data)){ ?>
  <div class="task-card">
    <div>
      <b><?= $r['title'] ?></b><br>
      <small><?= $r['remind_time'] ?></small>
    </div>

    <div class="task-action">
      <a href="reminder_edit.php?id=<?= $r['id'] ?>" class="btn-sm edit">Edit</a>
      <a href="reminder_delete.php?id=<?= $r['id'] ?>" class="btn-sm delete"
         onclick="return confirm('Hapus pengingat ini?')">Hapus</a>
    </div>
  </div>
<?php } ?>
</div>

      </div>

    </div>
  </div>

</div>

<!-- ================= NOTIFICATION SCRIPT ================= -->

<script src="theme.js"></script>

<script>
/* Minta izin notifikasi */
if ("Notification" in window) {
  if (Notification.permission !== "granted") {
    Notification.requestPermission();
  }
}

/* Data reminder dari database */
const reminders = [
<?php
$q = mysqli_query($conn,"SELECT * FROM reminders 
  WHERE user_id='$user_id' AND status='Pending'");
while($r=mysqli_fetch_assoc($q)){
  echo "{id:".$r['id'].", title:'".$r['title']."', time:'".$r['remind_time']."'},";
}
?>
];

/* Cek tiap 10 detik */
setInterval(()=>{
  let now = new Date().getTime();

  reminders.forEach(r=>{
    let remindTime = new Date(r.time).getTime();

    if(now >= remindTime){
      showNotif(r.title);
      markDone(r.id);
    }
  });
},10000);

/* Tampilkan notifikasi */
function showNotif(text){
  if(Notification.permission === "granted"){
    new Notification("⏰ Pinky Reminder",{
      body:text,
      icon:"logo.png"
    });
  }
}

/* Tandai sudah muncul */
function markDone(id){
  fetch("reminder_done.php?id="+id);
}
</script>

</body>
</html>
