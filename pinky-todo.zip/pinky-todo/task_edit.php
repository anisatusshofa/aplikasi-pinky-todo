<?php
include 'config.php';
if(!isset($_SESSION['user'])) header("Location: login.php");

$id = $_GET['id'];
$user_id = $_SESSION['user'];

$q = mysqli_query($conn,"SELECT * FROM tasks WHERE id='$id' AND user_id='$user_id'");
$data = mysqli_fetch_assoc($q);

if(isset($_POST['update'])){
  $title    = $_POST['title'];
  $desc     = $_POST['desc'];
  $priority = $_POST['priority'];
  $color    = $_POST['color'];
  $due      = $_POST['due'];

  mysqli_query($conn,"UPDATE tasks SET
    title='$title',
    description='$desc',
    priority='$priority',
    label_color='$color',
    due_date='$due'
    WHERE id='$id' AND user_id='$user_id'");

  header("Location: dashboard.php");
}
?>

<!DOCTYPE html>
<html>
<head>
  <title>Edit Task - Pinky</title>
  <link rel="stylesheet" href="style.css">
  <script src="script.js"></script>
</head>
<body class="<?= $_SESSION['theme'] ?>">

<div class="theme-toggle">
  <a href="theme.php" class="btn-sm">🌙 / ☀️</a>
</div>

<div class="dashboard-container">

<div class="sidebar">
  <h2>🐷 Pinky</h2>
  <a href="dashboard.php">🏠 Dashboard</a>
  <a href="pomodoro.php">🍅 Pomodoro</a>
  <a href="reminder.php">⏰ Pengingat</a>
  <a href="logout.php">🚪 Logout</a>
</div>

  <div class="main">

    <div class="task-section">

      <h2>Edit Task</h2>

      <form method="post" class="task-form">

        <input type="text" name="title" value="<?= $data['title'] ?>" required>

        <textarea name="desc"><?= $data['description'] ?></textarea>

        <select name="priority">
          <option value="Low" <?= $data['priority']=='Low'?'selected':'' ?>>Low Priority</option>
          <option value="Medium" <?= $data['priority']=='Medium'?'selected':'' ?>>Medium Priority</option>
          <option value="High" <?= $data['priority']=='High'?'selected':'' ?>>High Priority</option>
        </select>

        <label>Label Color</label>
        <input type="color" name="color" value="<?= $data['label_color'] ?>">

        <label>Due Date</label>
        <input type="date" name="due" value="<?= $data['due_date'] ?>" required>

        <button name="update" class="btn">Update Task</button>
        <a href="dashboard.php" class="btn btn-outline">Cancel</a>

      </form>

    </div>

  </div>
</div>

</body>
</html>
