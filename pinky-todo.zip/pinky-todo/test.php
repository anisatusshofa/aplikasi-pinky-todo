<?php
$conn = mysqli_connect("localhost","root","","pinky_todo");

if($conn){
    echo "Koneksi berhasil!";
}else{
    echo "Koneksi gagal!";
}
?>
