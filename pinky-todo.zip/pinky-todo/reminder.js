document.addEventListener("DOMContentLoaded", function(){

  if(Notification.permission !== "granted"){
    Notification.requestPermission();
  }

  const form = document.getElementById("reminderForm");
  const list = document.getElementById("reminderList");

  let reminders = JSON.parse(localStorage.getItem("reminders")) || [];

  renderReminders();

  form.addEventListener("submit", function(e){
    e.preventDefault();

    const title = document.getElementById("title").value;
    const time  = document.getElementById("time").value;

    const reminder = {
      title,
      time,
      triggered:false
    };

    reminders.push(reminder);
    localStorage.setItem("reminders", JSON.stringify(reminders));

    renderReminders();
    form.reset();
  });

  function renderReminders(){
    list.innerHTML = "";

    reminders.forEach((r,index)=>{
      const div = document.createElement("div");
      div.className = "task-card";

      div.innerHTML = `
        <div>
          <strong>${r.title}</strong><br>
          <small>${r.time}</small>
        </div>
        <button class="btn-sm delete" onclick="deleteReminder(${index})">Hapus</button>
      `;

      list.appendChild(div);
    });
  }

  window.deleteReminder = function(index){
    reminders.splice(index,1);
    localStorage.setItem("reminders", JSON.stringify(reminders));
    renderReminders();
  };

  // cek tiap detik
  setInterval(checkReminder,1000);

  function checkReminder(){
    const now = new Date().getTime();

    reminders.forEach(r=>{
      const remindTime = new Date(r.time).getTime();

      if(now >= remindTime && !r.triggered){
        r.triggered = true;
        showNotification(r.title);
      }
    });

    localStorage.setItem("reminders", JSON.stringify(reminders));
  }

  function showNotification(title){
    if(Notification.permission === "granted"){
      new Notification("⏰ Pengingat Pinky Pro",{
        body: title,
        icon: "logo.png"
      });
    }
  }

});

document.addEventListener("DOMContentLoaded", () => {

  if ("Notification" in window) {
    if (Notification.permission !== "granted") {
      Notification.requestPermission();
    }
  }

});
