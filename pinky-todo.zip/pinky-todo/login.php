<?php
include 'config.php';

if(isset($_SESSION['user'])){
  header("Location: dashboard.php");
  exit;
}

if(isset($_POST['login'])){
  $email = $_POST['email'];
  $pass  = md5($_POST['password']);

  $q = mysqli_query($conn,"SELECT * FROM users WHERE email='$email' AND password='$pass'");
  if(mysqli_num_rows($q) > 0){
    $u = mysqli_fetch_assoc($q);

    // Simpan session user
    $_SESSION['user']  = $u['id'];

    // Simpan theme user
    $_SESSION['theme'] = $u['theme'];

    header("Location: dashboard.php");
    exit;
  } else {
    $error = "Email atau password salah";
  }
}
?>

<!DOCTYPE html>
<html>
<head>
  <title>Login - Pinky</title>
  <link rel="stylesheet" href="style.css">
</head>

<body class="<?= isset($_SESSION['theme']) ? $_SESSION['theme'] : 'light' ?>">

<div class="theme-toggle">
  <a href="theme.php" class="btn-sm">🌙 / ☀️</a>
</div>

<div class="auth-container">
  <div class="auth-card">

    <h2>Login to Pinky</h2>

    <form method="post">
      <input type="email" name="email" placeholder="Email" required>
      <input type="password" name="password" placeholder="Password" required>

      <button name="login" class="btn">Login</button>

      <?php if(isset($error)){ ?>
        <p class="error"><?= $error ?></p>
      <?php } ?>

      <p>Belum punya akun? <a href="register.php">Register</a></p>
    </form>

  </div>
</div>

</body>
</html>
